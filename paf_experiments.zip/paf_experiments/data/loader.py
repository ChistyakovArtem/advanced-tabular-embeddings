"""
Data loading utilities.

Expects the TabM dataset layout from:
    https://www.kaggle.com/datasets/artemchistyakov/datasets-in-tabm

Each dataset lives in  <data_root>/<dataset_name>/  and contains:
    N_train.npy, N_val.npy, N_test.npy   — numerical features  (float32)
    y_train.npy, y_val.npy,  y_test.npy  — targets
    info.json                            — {"task_type": "regression"|"binclass"|"multiclass", ...}

Categorical features (C_*.npy) are ignored for now since our focus
is on *numerical* embeddings.
"""

import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import QuantileTransformer


# ---------------------------------------------------------------------------
# Low-level loaders
# ---------------------------------------------------------------------------

def _load_split(dataset_dir: Path, split: str) -> dict[str, np.ndarray]:
    """Load one split (train / val / test) from a dataset directory."""
    out: dict[str, np.ndarray] = {}

    num_path = dataset_dir / f"N_{split}.npy"
    if num_path.exists():
        out["X"] = np.load(num_path).astype(np.float32)
    else:
        raise FileNotFoundError(f"Numerical features not found: {num_path}")

    y_path = dataset_dir / f"y_{split}.npy"
    if y_path.exists():
        out["y"] = np.load(y_path)
    else:
        raise FileNotFoundError(f"Labels not found: {y_path}")

    return out


def _load_info(dataset_dir: Path) -> dict:
    info_path = dataset_dir / "info.json"
    if info_path.exists():
        with open(info_path) as f:
            return json.load(f)
    # Fallback: try to infer from unique label count
    return {"task_type": "regression"}


# ---------------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------------

def _apply_quantile_transform(
    X_train: np.ndarray,
    X_val: np.ndarray,
    X_test: np.ndarray,
    n_quantiles: int = 1000,
    output_distribution: str = "normal",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Fit QuantileTransformer on train, apply to all splits.
    Matches the preprocessing used in Gorishniy et al. (2022).
    """
    qt = QuantileTransformer(
        n_quantiles=min(n_quantiles, X_train.shape[0]),
        output_distribution=output_distribution,
        subsample=int(1e9),
        random_state=0,
    )
    X_train = qt.fit_transform(X_train).astype(np.float32)
    X_val   = qt.transform(X_val).astype(np.float32)
    X_test  = qt.transform(X_test).astype(np.float32)
    return X_train, X_val, X_test


def _normalise_target(
    y_train: np.ndarray, y_val: np.ndarray, y_test: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, float]:
    """Standardise regression target on train statistics."""
    mean = y_train.mean()
    std  = y_train.std() + 1e-8
    return ((y_train - mean) / std,
            (y_val   - mean) / std,
            (y_test  - mean) / std,
            float(mean), float(std))


# ---------------------------------------------------------------------------
# Main public function
# ---------------------------------------------------------------------------

def load_dataset(
    dataset_name: str,
    data_root: str | Path = "data",
    apply_quantile: bool = True,
    batch_size: int = 256,
    num_workers: int = 0,
) -> dict:
    """
    Load a single dataset and return a dict with:
        loaders   : {"train": DataLoader, "val": DataLoader, "test": DataLoader}
        n_features: int
        task_type : str   "regression" | "binclass" | "multiclass"
        n_classes : int   (1 for regression/binclass)
        y_stats   : {"mean": float, "std": float}  (only for regression)
        dataset_name : str

    DataLoaders yield (X, y) pairs of float32 tensors.
    """
    data_root = Path(data_root)
    dataset_dir = data_root / dataset_name

    if not dataset_dir.exists():
        raise FileNotFoundError(
            f"Dataset directory not found: {dataset_dir}\n"
            f"Expected layout: {data_root}/<dataset_name>/N_train.npy ..."
        )

    info = _load_info(dataset_dir)
    task_type: str = info.get("task_type", "regression")

    train = _load_split(dataset_dir, "train")
    val   = _load_split(dataset_dir, "val")
    test  = _load_split(dataset_dir, "test")

    X_train, y_train = train["X"], train["y"]
    X_val,   y_val   = val["X"],   val["y"]
    X_test,  y_test  = test["X"],  test["y"]

    # -- Feature preprocessing --
    if apply_quantile:
        X_train, X_val, X_test = _apply_quantile_transform(
            X_train, X_val, X_test
        )

    # -- Target preprocessing --
    y_stats: dict[str, float] = {}
    if task_type == "regression":
        y_train, y_val, y_test, y_mean, y_std = _normalise_target(
            y_train.astype(np.float32),
            y_val.astype(np.float32),
            y_test.astype(np.float32),
        )
        y_stats = {"mean": y_mean, "std": y_std}
        y_dtype = torch.float32
    elif task_type == "binclass":
        y_dtype = torch.float32   # BCEWithLogitsLoss expects float
    else:
        y_dtype = torch.long      # CrossEntropyLoss

    def _make_loader(X: np.ndarray, y: np.ndarray, shuffle: bool) -> DataLoader:
        ds = TensorDataset(
            torch.tensor(X, dtype=torch.float32),
            torch.tensor(y, dtype=y_dtype),
        )
        return DataLoader(ds, batch_size=batch_size,
                          shuffle=shuffle, num_workers=num_workers,
                          pin_memory=True)

    # n_classes
    if task_type == "multiclass":
        n_classes = int(np.unique(y_train).size)
    else:
        n_classes = 1

    return {
        "loaders": {
            "train": _make_loader(X_train, y_train, shuffle=True),
            "val":   _make_loader(X_val,   y_val,   shuffle=False),
            "test":  _make_loader(X_test,  y_test,  shuffle=False),
        },
        "n_features":   X_train.shape[1],
        "task_type":    task_type,
        "n_classes":    n_classes,
        "y_stats":      y_stats,
        "dataset_name": dataset_name,
    }


def load_datasets(
    dataset_names: list[str],
    data_root: str | Path = "data",
    **kwargs,
) -> dict[str, dict]:
    """Load multiple datasets, return dict keyed by name."""
    return {
        name: load_dataset(name, data_root=data_root, **kwargs)
        for name in dataset_names
    }
