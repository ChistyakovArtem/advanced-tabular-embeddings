"""
Results analysis.

Loads all_results.json and prints a formatted summary table.
Also computes rank vs MLP baseline.
"""

import json
import statistics
from pathlib import Path
from collections import defaultdict

from experiments.runner import ALL_VARIANTS


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

def aggregate(results: list[dict]) -> dict[str, dict[str, dict]]:
    """
    Returns nested dict:
        {dataset_name: {model_name: {"val_mean", "val_std", "test_mean", "test_std", "n_params"}}}
    """
    # group by (dataset, model)
    groups: dict[tuple, list] = defaultdict(list)
    for r in results:
        key = (r["dataset_name"], r["model_name"])
        groups[key].append(r)

    out: dict[str, dict[str, dict]] = defaultdict(dict)
    for (ds, model), runs in groups.items():
        vals  = [r["best_val_metric"] for r in runs]
        tests = [r["test_metric"]     for r in runs]
        out[ds][model] = {
            "val_mean":   statistics.mean(vals),
            "val_std":    statistics.stdev(vals) if len(vals) > 1 else 0.0,
            "test_mean":  statistics.mean(tests),
            "test_std":   statistics.stdev(tests) if len(tests) > 1 else 0.0,
            "n_params":   runs[0].get("n_params", 0),
            "n_seeds":    len(runs),
        }
    return dict(out)


# ---------------------------------------------------------------------------
# Pretty-print table
# ---------------------------------------------------------------------------

def _metric_str(mean: float, std: float, task_type: str) -> str:
    """Format metric. For regression we stored negative RMSE; flip sign."""
    if task_type == "regression":
        # stored as -RMSE (higher = better); display as RMSE (lower = better)
        return f"{-mean:.4f} ± {std:.4f}"
    return f"{mean:.4f} ± {std:.4f}"


def print_table(
    agg: dict[str, dict[str, dict]],
    task_types: dict[str, str] | None = None,
) -> None:
    """
    Print one table per dataset.

    agg        : output of aggregate()
    task_types : {dataset_name: task_type}  — for display formatting
    """
    if task_types is None:
        task_types = {}

    for ds_name, models in agg.items():
        task = task_types.get(ds_name, "regression")
        metric_name = "RMSE ↓" if task == "regression" else "Acc ↑"

        print(f"\n{'='*72}")
        print(f"  Dataset: {ds_name}  ({metric_name})")
        print(f"{'='*72}")
        print(f"  {'Model':<30}  {'Val metric':>20}  {'Test metric':>20}  {'#params':>10}")
        print(f"  {'-'*30}  {'-'*20}  {'-'*20}  {'-'*10}")

        # Sort: baseline first, then embedding, then PAFNet
        ordered = [v for v in ALL_VARIANTS if v in models]
        # add any variants present in results but not in ALL_VARIANTS
        ordered += [v for v in sorted(models) if v not in ordered]

        baseline_test = None
        for model_name in ordered:
            if model_name not in models:
                continue
            m = models[model_name]

            val_s  = _metric_str(m["val_mean"],  m["val_std"],  task)
            test_s = _metric_str(m["test_mean"], m["test_std"], task)

            # delta vs MLP baseline (test metric, sign-aware)
            delta_str = ""
            if model_name == "MLP":
                baseline_test = m["test_mean"]
            elif baseline_test is not None:
                delta = m["test_mean"] - baseline_test
                arrow = "▲" if delta > 0 else "▼"
                delta_str = f"  {arrow}{abs(delta):.4f}"

            print(
                f"  {model_name:<30}  {val_s:>20}  {test_s:>20}{delta_str:<12}"
                f"  {m['n_params']:>10,}"
            )

        print()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(results_path: str = "results/all_results.json") -> None:
    p = Path(results_path)
    if not p.exists():
        print(f"Results file not found: {p}")
        return

    results = json.loads(p.read_text())
    agg = aggregate(results)

    # Try to recover task types from results
    task_types: dict[str, str] = {}
    for r in results:
        if r["dataset_name"] not in task_types:
            # Not stored in slim JSON — infer from metric sign convention:
            # regression metrics are stored as negative RMSE (< 0 for valid models)
            # Use heuristic: if all test metrics < 0 → regression
            pass  # will default to "regression" which is fine for CA Housing

    print_table(agg, task_types)


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "results/all_results.json"
    main(path)
