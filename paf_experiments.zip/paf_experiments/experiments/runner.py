"""
Experiment runner.

Defines all model variants and runs them on one or more datasets.

Model variants
--------------
Baseline:
    MLP                 — vanilla MLP

Embedding-only (PAF as input embedding only, MLP backbone):
    EmbMLP-orig-plain   — OriginalPeriodic(plain)  + MLP  [matches paper MLP-P]
    EmbMLP-orig-sc      — OriginalPeriodic(sc)     + MLP
    EmbMLP-orig-sc_af   — OriginalPeriodic(sc_af)  + MLP
    EmbMLP-grid-plain   — GridPeriodic(plain)       + MLP
    EmbMLP-grid-sc      — GridPeriodic(sc)          + MLP
    EmbMLP-grid-sc_af   — GridPeriodic(sc_af)       + MLP

PAF-Net (PAF as activation inside the network):
    PAFNet-plain-ln     — PAFNet(plain,  use_layernorm=True)
    PAFNet-sc-ln        — PAFNet(sc,     use_layernorm=True)
    PAFNet-sc_af-ln     — PAFNet(sc_af,  use_layernorm=True)
    PAFNet-plain-noln   — PAFNet(plain,  use_layernorm=False)  ablation
    PAFNet-sc-noln      — PAFNet(sc,     use_layernorm=False)  ablation
    PAFNet-sc_af-noln   — PAFNet(sc_af,  use_layernorm=False)  ablation

Total: 13 variants (1 baseline + 6 embedding + 6 PAFNet)

The `-ln` vs `-noln` split replaces the original `-const` vs `-grid` split.
Rationale: inside a network, the key question is not "how to initialise σ"
but "how to keep activation scales controlled across layers".  LayerNorm
addresses this directly.  The grid-σ idea remains relevant for the input
embedding variants (GridPeriodic) where it replaces HPO.
"""

import json
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn

from models.embeddings import OriginalPeriodic, GridPeriodic, build_embedding
from models.backbones  import MLP, PAFNet, EmbeddingMLP
from experiments.trainer import train


# ---------------------------------------------------------------------------
# Default hyperparameters (fixed, no HPO — intentional for this study)
# ---------------------------------------------------------------------------

@dataclass
class DefaultHParams:
    # Architecture
    hidden_dim   : int   = 256
    n_layers     : int   = 3
    k            : int   = 48      # frequencies for Periodic / PAF
    dropout      : float = 0.1
    sigma_init   : float = 1.0     # for OriginalPeriodic embedding init only

    # Training
    lr           : float = 1e-3
    weight_decay : float = 1e-5
    n_epochs     : int   = 100
    patience     : int   = 16
    batch_size   : int   = 256

    # Infra
    seed         : int   = 42
    n_seeds      : int   = 3       # repeat each experiment n_seeds times


# ---------------------------------------------------------------------------
# Model factory
# ---------------------------------------------------------------------------

def _build_model(
    name: str,
    n_features: int,
    n_classes: int,
    task_type: str,
    hp: DefaultHParams,
) -> nn.Module:
    out_dim = n_classes if task_type == "multiclass" else 1

    # ---- Baseline ----
    if name == "MLP":
        return MLP(
            in_dim=n_features,
            hidden_dim=hp.hidden_dim,
            n_layers=hp.n_layers,
            out_dim=out_dim,
            dropout=hp.dropout,
        )

    # ---- Embedding-only variants ----
    if name.startswith("EmbMLP-"):
        # e.g. "EmbMLP-grid-sc_af"  ->  emb_type="grid", variant="sc_af"
        parts = name.split("-")          # ["EmbMLP", "grid", "sc_af"]
        emb_type = parts[1]              # "orig" | "grid"
        variant  = parts[2]              # "plain" | "sc" | "sc_af"

        emb_name = "original" if emb_type == "orig" else "grid"
        extra = {} if emb_name == "grid" else {"sigma": hp.sigma_init}
        embedding = build_embedding(
            name=emb_name,
            n_features=n_features,
            k=hp.k,
            variant=variant,
            **extra,
        )
        return EmbeddingMLP(
            embedding=embedding,
            n_features=n_features,
            hidden_dim=hp.hidden_dim,
            n_layers=hp.n_layers,
            out_dim=out_dim,
            dropout=hp.dropout,
        )

    # ---- PAFNet variants ----
    if name.startswith("PAFNet-"):
        # e.g. "PAFNet-sc_af-ln"  ->  variant="sc_af", use_ln=True
        parts         = name.split("-")   # ["PAFNet", "sc_af", "ln"]
        variant       = parts[1]
        use_layernorm = parts[2] == "ln"
        return PAFNet(
            in_dim=n_features,
            k=hp.k,
            n_layers=hp.n_layers,
            out_dim=out_dim,
            paf_variant=variant,
            use_layernorm=use_layernorm,
            dropout=hp.dropout,
        )

    raise ValueError(f"Unknown model name: {name!r}")


# All 13 variant names (order = display order in results table)
ALL_VARIANTS: list[str] = [
    "MLP",
    # --- embedding-only ---
    "EmbMLP-orig-plain",
    "EmbMLP-orig-sc",
    "EmbMLP-orig-sc_af",
    "EmbMLP-grid-plain",
    "EmbMLP-grid-sc",
    "EmbMLP-grid-sc_af",
    # --- PAFNet (ln = with LayerNorm, noln = ablation without) ---
    "PAFNet-plain-ln",
    "PAFNet-sc-ln",
    "PAFNet-sc_af-ln",
    "PAFNet-plain-noln",
    "PAFNet-sc-noln",
    "PAFNet-sc_af-noln",
]


# ---------------------------------------------------------------------------
# Single experiment
# ---------------------------------------------------------------------------

def run_one(
    model_name: str,
    dataset: dict,
    hp: DefaultHParams,
    results_dir: Path,
    device: torch.device,
    seed: int,
    verbose: bool = True,
) -> dict[str, Any]:
    torch.manual_seed(seed)

    model = _build_model(
        model_name,
        n_features=dataset["n_features"],
        n_classes=dataset["n_classes"],
        task_type=dataset["task_type"],
        hp=hp,
    )

    ckpt = results_dir / dataset["dataset_name"] / model_name / f"seed{seed}.pt"

    result = train(
        model=model,
        dataset=dataset,
        lr=hp.lr,
        weight_decay=hp.weight_decay,
        n_epochs=hp.n_epochs,
        patience=hp.patience,
        device=device,
        checkpoint_path=ckpt,
        verbose=verbose,
    )
    result["model_name"]   = model_name
    result["dataset_name"] = dataset["dataset_name"]
    result["seed"]         = seed
    result["n_params"]     = sum(p.numel() for p in model.parameters())
    return result


# ---------------------------------------------------------------------------
# Full experiment grid
# ---------------------------------------------------------------------------

def run_experiments(
    dataset_names: list[str],
    data_root:     str | Path = "data",
    results_dir:   str | Path = "results",
    variants:      list[str] | None = None,
    hp:            DefaultHParams | None = None,
    device:        torch.device | None = None,
    verbose:       bool = True,
) -> list[dict[str, Any]]:
    """
    Run all model variants on all datasets (with hp.n_seeds seeds each).

    Parameters
    ----------
    dataset_names : list of dataset folder names under data_root
    data_root     : root directory for datasets
    results_dir   : where to save checkpoints and result JSON
    variants      : subset of ALL_VARIANTS to run (default: all)
    hp            : hyperparameters (default: DefaultHParams())
    device        : torch device
    verbose       : per-epoch printing

    Returns
    -------
    List of result dicts (one per model × dataset × seed).
    """
    from data.loader import load_dataset

    if hp      is None: hp      = DefaultHParams()
    if variants is None: variants = ALL_VARIANTS
    if device  is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    results_dir = Path(results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)

    all_results: list[dict] = []

    for ds_name in dataset_names:
        print(f"\n{'='*60}")
        print(f"  Dataset: {ds_name}")
        print(f"{'='*60}")

        dataset = load_dataset(
            ds_name,
            data_root=data_root,
            batch_size=hp.batch_size,
        )
        print(
            f"  n_features={dataset['n_features']}  "
            f"task={dataset['task_type']}  "
            f"n_classes={dataset['n_classes']}"
        )

        for model_name in variants:
            seed_results = []
            for seed_idx in range(hp.n_seeds):
                actual_seed = hp.seed + seed_idx
                print(f"\n  [{model_name}]  seed={actual_seed}")
                r = run_one(
                    model_name=model_name,
                    dataset=dataset,
                    hp=hp,
                    results_dir=results_dir,
                    device=device,
                    seed=actual_seed,
                    verbose=verbose,
                )
                seed_results.append(r)
                all_results.append(r)

            # Print seed-averaged summary
            vals  = [r["best_val_metric"] for r in seed_results]
            tests = [r["test_metric"]     for r in seed_results]
            import statistics
            print(
                f"  → {model_name:30s} "
                f"val={statistics.mean(vals):.4f}±{statistics.stdev(vals) if len(vals)>1 else 0:.4f}  "
                f"test={statistics.mean(tests):.4f}±{statistics.stdev(tests) if len(tests)>1 else 0:.4f}"
            )

    # Save raw results to JSON
    out_path = results_dir / "all_results.json"
    # Remove non-serialisable history (large) from saved JSON
    slim = [{k: v for k, v in r.items() if k != "history"}
            for r in all_results]
    out_path.write_text(json.dumps(slim, indent=2))
    print(f"\nResults saved to {out_path}")

    return all_results
