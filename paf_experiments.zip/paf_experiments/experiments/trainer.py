"""
Training loop and evaluation.

Supports regression, binary classification, multiclass classification.
Returns per-epoch metrics and saves best checkpoint by val score.
"""

import math
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader


# ---------------------------------------------------------------------------
# Loss / metric helpers
# ---------------------------------------------------------------------------

def _get_loss_fn(task_type: str) -> nn.Module:
    if task_type == "regression":
        return nn.MSELoss()
    if task_type == "binclass":
        return nn.BCEWithLogitsLoss()
    return nn.CrossEntropyLoss()


def _compute_metric(
    logits: torch.Tensor,
    y: torch.Tensor,
    task_type: str,
) -> float:
    """Returns scalar metric (higher = better, except RMSE where lower = better)."""
    with torch.no_grad():
        if task_type == "regression":
            # RMSE (will be negated for "higher-is-better" comparison)
            return -math.sqrt(nn.functional.mse_loss(logits.squeeze(), y).item())
        if task_type == "binclass":
            preds = (logits.squeeze() > 0).long()
            return (preds == y.long()).float().mean().item()
        # multiclass
        preds = logits.argmax(dim=-1)
        return (preds == y).float().mean().item()


# ---------------------------------------------------------------------------
# One epoch
# ---------------------------------------------------------------------------

def _run_epoch(
    model: nn.Module,
    loader: DataLoader,
    loss_fn: nn.Module,
    task_type: str,
    optimizer: optim.Optimizer | None,
    device: torch.device,
) -> tuple[float, float]:
    """Returns (avg_loss, metric)."""
    training = optimizer is not None
    model.train(training)

    total_loss = 0.0
    all_logits: list[torch.Tensor] = []
    all_y:      list[torch.Tensor] = []

    with torch.set_grad_enabled(training):
        for X_batch, y_batch in loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            logits = model(X_batch)

            # Loss expects (B,) for regression/binclass
            if task_type in ("regression", "binclass"):
                loss = loss_fn(logits.squeeze(), y_batch)
            else:
                loss = loss_fn(logits, y_batch)

            if training:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            total_loss += loss.item() * len(y_batch)
            all_logits.append(logits.detach().cpu())
            all_y.append(y_batch.detach().cpu())

    logits_all = torch.cat(all_logits)
    y_all      = torch.cat(all_y)
    metric     = _compute_metric(logits_all, y_all, task_type)
    avg_loss   = total_loss / len(y_all)

    return avg_loss, metric


# ---------------------------------------------------------------------------
# Full training run
# ---------------------------------------------------------------------------

def train(
    model: nn.Module,
    dataset: dict,
    *,
    lr: float = 1e-3,
    weight_decay: float = 1e-5,
    n_epochs: int = 100,
    patience: int = 16,
    device: torch.device | None = None,
    checkpoint_path: Path | None = None,
    verbose: bool = True,
) -> dict[str, Any]:
    """
    Train model and return results dict.

    Parameters
    ----------
    model          : nn.Module
    dataset        : dict as returned by data.loader.load_dataset()
    lr             : learning rate
    weight_decay   : L2 regularisation
    n_epochs       : max epochs
    patience       : early stopping patience (on val metric)
    device         : defaults to cuda if available
    checkpoint_path: where to save best model weights (.pt)
    verbose        : print per-epoch summary

    Returns
    -------
    {
        "best_val_metric": float,
        "test_metric":     float,
        "best_epoch":      int,
        "history":         list[dict],   # per-epoch train/val loss+metric
        "train_time_s":    float,
    }
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = model.to(device)
    task_type = dataset["task_type"]
    loss_fn   = _get_loss_fn(task_type)

    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    loaders = dataset["loaders"]
    best_val_metric = -math.inf
    best_epoch      = 0
    no_improve      = 0
    best_state      = None
    history: list[dict] = []

    t0 = time.time()

    for epoch in range(1, n_epochs + 1):
        tr_loss, tr_metric = _run_epoch(
            model, loaders["train"], loss_fn, task_type, optimizer, device
        )
        val_loss, val_metric = _run_epoch(
            model, loaders["val"], loss_fn, task_type, None, device
        )

        row = {
            "epoch":      epoch,
            "train_loss": tr_loss,
            "val_loss":   val_loss,
            "train_metric": tr_metric,
            "val_metric": val_metric,
        }
        history.append(row)

        if val_metric > best_val_metric:
            best_val_metric = val_metric
            best_epoch      = epoch
            no_improve      = 0
            best_state      = {k: v.cpu().clone()
                               for k, v in model.state_dict().items()}
            if checkpoint_path is not None:
                checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
                torch.save(best_state, checkpoint_path)
        else:
            no_improve += 1

        if verbose and (epoch % 10 == 0 or epoch == 1):
            sign = "↑" if task_type == "regression" else ""
            print(
                f"  [{epoch:>4}] "
                f"train_loss={tr_loss:.4f}  val_loss={val_loss:.4f}  "
                f"val_metric={val_metric:.4f}{sign}  "
                f"{'*' if no_improve == 0 else ''}"
            )

        if no_improve >= patience:
            if verbose:
                print(f"  Early stop at epoch {epoch} (patience={patience})")
            break

    # Restore best weights and evaluate on test
    if best_state is not None:
        model.load_state_dict(best_state)

    _, test_metric = _run_epoch(
        model, loaders["test"], loss_fn, task_type, None, device
    )
    train_time = time.time() - t0

    if verbose:
        print(
            f"  → best_epoch={best_epoch}  "
            f"best_val={best_val_metric:.4f}  "
            f"test={test_metric:.4f}  "
            f"({train_time:.1f}s)"
        )

    return {
        "best_val_metric": best_val_metric,
        "test_metric":     test_metric,
        "best_epoch":      best_epoch,
        "history":         history,
        "train_time_s":    train_time,
    }
